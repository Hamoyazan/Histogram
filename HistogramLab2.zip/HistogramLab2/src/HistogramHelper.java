import java.io.*;
import java.util.*;

public class HistogramHelper {

    //Allgemeine Methode zum Zählen der Anfangsbuchstaben (A-Z) aus einem beliebigen Reader (Datei oder String)
    public static Map<Character, Integer> countCharacters(Reader reader) throws IOException {
        Map<Character, Integer> frequencies = new HashMap<>();
        BufferedReader bufferedReader = new BufferedReader(reader);
        String line;

        while ((line = bufferedReader.readLine()) != null) {
            line = line.trim();
            if (!line.isEmpty()) {
                // Erster Buchstabe extrahieren und in Großbuchstabe umwandeln
                char firstChar = Character.toUpperCase(line.charAt(0));
                // Nur Buchstaben von A bis Z zählen
                if (firstChar >= 'A' && firstChar <= 'Z') {
                    frequencies.put(firstChar, frequencies.getOrDefault(firstChar, 0) + 1);
                }
            }
        }

        return frequencies;
    }

    //Gibt das Histogramm im Terminal als Textgrafik mit '#' aus
    public static void printHistogramToConsole(Map<Character, Integer> frequencies) {
        System.out.println("\nHistogramm in der Konsole:");
        for (char c = 'A'; c <= 'Z'; c++) {
            int count = frequencies.getOrDefault(c, 0);
            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < count; i++) {
                bar.append('#');
            }
            System.out.println(c + ": " + bar + " (" + count + ")");
        }
    }

    //Schreibt das Histogramm in eine Ausgabedatei (z. B. frequency.txt)
    public static void writeHistogramToFile(Map<Character, Integer> frequencies, String outputFile) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            for (char c = 'A'; c <= 'Z'; c++) {
                int count = frequencies.getOrDefault(c, 0);
                StringBuilder bar = new StringBuilder();
                for (int i = 0; i < count; i++) {
                    bar.append('#');
                }
                writer.write(c + ": " + bar + " (" + count + ")");
                writer.newLine();
            }
            System.out.println("\nDas Histogramm wurde in der Datei " + outputFile + " gespeichert.");
        } catch (IOException e) {
            System.out.println("Fehler beim Schreiben: " + e.getMessage());
        }
    }

    public static void main(String[] args) {

        try {
            //Einlesen der Eingabedatei (input.txt)
            FileReader fileReader = new FileReader("src/input.txt");
            Map<Character, Integer> result = countCharacters(fileReader);

            //Histogramm auf der Konsole anzeigen
            printHistogramToConsole(result);

            //Histogramm zusätzlich in eine Datei schreiben
            writeHistogramToFile(result, "src/frequency.txt");

        } catch (IOException e) {
            System.out.println("Fehler beim Lesen: " + e.getMessage());
        }

        //(Optional) Beispiel mit manuell definiertem Text
        /*
        try {
            String text = "Apfel\nBirne\nZitrone\nZug\nZucker\n";
            StringReader stringReader = new StringReader(text);
            Map<Character, Integer> resultFromText = countCharacters(stringReader);
            printHistogramToConsole(resultFromText);
        } catch (IOException e) {
            System.out.println("Fehler beim Lesen aus String: " + e.getMessage());
        }
        */
    }
}
